﻿using DriverLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VehicleLibrary;

namespace AdminLibrary
{
    public class Admin
    {
        private List<Driver> driversList ;
        
        public Admin(ref List<Driver> driversList) {
      
            this.driversList = driversList;
        }

        public void deleteDriver()
        {
            Console.Write("Enter ID: ");
            bool flag = false;
            int id = Convert.ToInt32(Console.ReadLine());
            for (int j = 0; j < driversList.Count(); j++)
            {
                if (driversList[j].Id == id)
                {
                    driversList.RemoveAt(j);
                    flag = true;
                    break;
                }
            }
            if (!flag)
            {
                Console.WriteLine("* Driver Not Found");
            }
        }

        public void AddDriver()
        {
            bool flag = true;
            Console.Write("Enter Name: ");
            string name = Console.ReadLine();
            int age = 0;
            while (age <= 0)
            {
                Console.Write("Enter Age: ");
                age = Convert.ToInt32(Console.ReadLine());
            }

            Console.Write("Enter Phone No: ");
            string num = Console.ReadLine();
            while ((num.Length != 11 || !num.All(char.IsDigit)))
            {
                Console.Write("Enter Phone No: ");
                num = Console.ReadLine();
            }
            string gender = "";
            while (flag)
            {
                Console.Write("Enter Gender: ");
                gender = Console.ReadLine();
                gender = gender.Replace(" ", "");
                if (gender.ToLower() == "male" || gender.ToLower() == "female")
                {
                    flag = false;
                }
            }

            Console.Write("Enter Address: ");
            string address = Console.ReadLine();

            flag = true;
            string type = "";
            while (flag)
            {
                Console.Write("Enter Vehicle Type: ");
                type = Console.ReadLine().Replace(" ", "");
                if (type.ToLower() == "car")
                {
                    flag = false;

                }
                else if (type.ToLower() == "rickshaw")
                {
                    flag = false;

                }
                else if (type.ToLower() == "bike")
                {
                    flag = false;

                }
            }
            flag = true;
            string model = "";
            while (flag)
            {
                Console.Write("Enter Vehicle Model: ");
                model = Console.ReadLine();
                if (model != "" && model.All(char.IsDigit) && model.Length == 4)
                {
                    flag = false;
                }
            }

            flag = false;
            string plate = "";
            while (!flag)
            {
                flag = true;
                Console.Write("Enter Vehicle License Plate: ");
                plate = Console.ReadLine();
                string temp = plate.ToLower();
                if (plate.Length == 8)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        if ((i >= 0 && i <= 2) && (temp[i] >= 'a' && temp[i] <= 'z'))
                        {

                        }
                        else if (i == 3 && temp[i] == ' ')
                        {

                        }
                        else if ((i >= 4 && i <= 7) && (temp[i] >= '0' && temp[i] <= '9'))
                        {

                        }
                        else
                        {
                            flag = false;
                        }
                    }
                }
                else
                {
                    flag = false;
                }
            }

            Vehicle s = new Vehicle(type: type, model: model, licensePlate: plate);
            Driver adding = new Driver(name: name, age: Convert.ToInt32(age), address: address, phoneNo: num, vehicle: s, gender: gender);
            driversList.Add(adding);
        }

        public void updateDriver()
        {
            if (driversList.Count == 0)
            {
                Console.WriteLine("** No Driver Found");
                return;
            }
            int id = 0;
            while (id <= 0)
            {
                Console.Write("Enter Driver ID: ");
                id = Convert.ToInt32(Console.ReadLine());
            }
            for (int j = 0; j < driversList.Count(); j++)
            {
                if (driversList[j].Id == id)
                {
                    Console.WriteLine($"\n-------------Driver with ID  {driversList[j].Id} exists-------------\n");
                    Console.Write("\n Enter Name: ");
                    string name = Console.ReadLine();
                    if (name != "")
                    {
                        driversList[j].Name = name;
                    }
                    bool flag = true;
                    string age = "";
                    while (flag)
                    {
                        Console.Write("\n Enter Age: ");
                        age = Console.ReadLine();
                        if (age != "" && age.All(char.IsDigit))
                        {
                            flag = false;
                            driversList[j].Age = Convert.ToInt32(age);
                        }
                        if (age == "")
                        {
                            flag = false;
                        }
                    }
                    flag = true;
                    string gender = "";
                    while (flag)
                    {
                        Console.Write("\n Enter Gender: ");
                        gender = Console.ReadLine();
                        gender = gender.Replace(" ", "");
                        if (gender != "" && (gender.ToLower() == "male" || gender.ToLower() == "female"))
                        {
                            flag = false;
                            driversList[j].Gender = gender;
                        }
                        if (gender == "")
                        {
                            flag = false;
                        }
                    }
                    flag = true;
                    string type = "";
                    while (flag)
                    {
                        Console.Write("\n Enter Vehicle Type: ");
                        type = Console.ReadLine();
                        type = type.Replace(" ", "");
                        if (type != "" && type.ToLower() == "car")
                        {
                            flag = false;
                            driversList[j].vehicleType = type;

                        }
                        else if (type != "" && type.ToLower() == "rickshaw")
                        {
                            flag = false;
                            driversList[j].vehicleType = type;
                        }
                        else if (type != "" && type.ToLower() == "bike")
                        {
                            flag = false;
                            driversList[j].vehicleType = type;

                        }
                        if (type == "")
                        {
                            flag = false;
                        }
                    }
                    flag = true;
                    string model = "";
                    while (flag)
                    {
                        Console.Write("\n Enter Vehicle Model: ");
                        model = Console.ReadLine();
                        if (model != "" && model.All(char.IsDigit) && model.Length == 4)
                        {
                            flag = false;
                            driversList[j].vehicleModel = model;
                        }
                        if (model == "")
                        {
                            flag = false;
                        }
                    }
                    flag = false;
                    string plate = "";
                    while (!flag)
                    {
                        flag = true;
                        Console.Write("\n Enter Vehicle License Plate: ");
                        plate = Console.ReadLine();
                        string temp = plate.ToLower();
                        if (plate.Length == 8)
                        {
                            for (int i = 0; i < 8; i++)
                            {
                                if ((i >= 0 && i <= 2) && (temp[i] >= 'a' && temp[i] <= 'z'))
                                {

                                }
                                else if (i == 3 && temp[i] == ' ')
                                {

                                }
                                else if ((i >= 4 && i <= 7) && (temp[i] >= '0' && temp[i] <= '9'))
                                {

                                }
                                else
                                {
                                    flag = false;
                                }
                            }
                            if (flag)
                            {
                                driversList[j].vehicleLicensePlate = plate;
                                return;
                            }
                        }
                        else if (plate == "")
                        {
                            return;
                        }
                        else
                        {
                            flag = false;
                        }
                    }
                    return;
                }
            }
            Console.WriteLine("\n Driver with this ID does not exist !!!!");

        }

        public void SearchDriver()
        {
            bool flag = true;
            string id = "";
            while (flag)
            {
                Console.Write("Enter ID: ");
                id = Console.ReadLine();
                if (id == "" || id.All(char.IsDigit))
                {
                    flag = false;
                }
            }
            Console.Write("Enter Name: ");
            string name = Console.ReadLine();
            flag = true;
            string age = "";
            while (flag)
            {
                Console.Write("Enter Age: ");
                age = Console.ReadLine();
                if (age == "" || age.All(char.IsDigit))
                {
                    flag = false;
                }
            }
            Console.Write("Enter Gender: ");
            string gender = Console.ReadLine();
            Console.Write("Enter Address: ");
            string address = Console.ReadLine();

            flag = true;
            string type = "";
            while (flag)
            {
                Console.Write("Enter Vehicle Type: ");
                type = Console.ReadLine();
                type = type.Replace(" ", "");
                if (type.ToLower() == "car")
                {
                    flag = false;

                }
                else if (type.ToLower() == "rickshaw")
                {
                    flag = false;

                }
                else if (type.ToLower() == "bike")
                {
                    flag = false;

                }
                else if (type == "")
                {
                    flag = false;
                }
            }
            flag = true;
            string model = "";
            while (flag)
            {
                Console.Write("Enter Vehicle Model: ");
                model = Console.ReadLine();
                if (model == "" || model.All(char.IsDigit))
                {
                    flag = false;
                }
            }

            Console.Write("Enter Vehicle License Plate: ");
            string plate = Console.ReadLine();
            int i = 0;
            Driver temp = null;
            foreach (var driver in driversList)
            {

                if (id == "")
                {
                    i++;
                }
                else if (Convert.ToInt32(id) == driver.Id)
                {
                    i++;
                }

                Console.WriteLine(driver.Name);  

                if (name.ToLower() == Convert.ToString(driver.Name).ToLower())
                {
                    i++;
                }
                else if (name == "")
                {
                    i++;
                }


                if (age == "")
                {
                    i++;
                }
                else if (Convert.ToInt32(age) == driver.Age)
                {
                    i++;
                }


                if (gender == "")
                {
                    i++;
                }
                else if (gender.ToLower() == driver.Gender.ToLower())
                {
                    i++;
                }


                if (type == "")
                {
                    i++;
                }
                else if (type.ToLower() == driver.vehicleType.ToLower())
                {
                    i++;
                }


                if (model == "")
                {
                    i++;
                }
                else if (model == driver.vehicleModel)
                {
                    i++;
                }


                if (plate == "")
                {
                    i++;
                }
                else if (plate == driver.vehicleLicensePlate)
                {
                    i++;
                }
                if (i == 7)
                {
                    temp = driver;
                    break;
                }
                else
                {
                    i = 0;
                }
            }

            if (temp != null)
            {
                Console.WriteLine("--------------------------------------------------------------------------------------------------------\n");
                Console.WriteLine($"Name: ", temp.Name);
                Console.WriteLine($"Age: ", temp.Age);
                Console.WriteLine($"Gender: ", temp.Gender);
                Console.WriteLine($"V.Type: ", temp.vehicleType);
                Console.WriteLine($"V.Model: ", temp.vehicleModel);
                Console.WriteLine($"V.License: ", temp.vehicleLicensePlate);
                Console.WriteLine("--------------------------------------------------------------------------------------------------------\n");
            }
            else
            {
                Console.WriteLine("* No Driver Match");
            }

        }


    }
}
